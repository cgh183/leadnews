package com.heima.model.admin.pojos;


import com.heima.model.wemedia.pojos.WmChannel;
import lombok.Data;

@Data
public class AdChannel extends WmChannel {

}
