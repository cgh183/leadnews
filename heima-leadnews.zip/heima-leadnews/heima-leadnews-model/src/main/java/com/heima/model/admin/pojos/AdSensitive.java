package com.heima.model.admin.pojos;

import com.heima.model.wemedia.pojos.WmSensitive;
import lombok.Data;

@Data
public class AdSensitive extends WmSensitive {

}
