package com.heima.user.mapper;
 
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.heima.model.admin.pojos.ApUserRealname;
import org.apache.ibatis.annotations.Mapper;
 
/**
 * @author Z-熙玉
 * @version 1.0
 */
@Mapper
public interface ApUserRealnameMapper extends BaseMapper<ApUserRealname> {

}