package com.heima.hehavior;


@SpringBootApplication
@EnableDiscoveryClient
@MapperScan("com.heima.behavior.mapper")
@EnableTransactionManagement
@EnableFeignClients(basePackages = "com.heima.apis")
public class BehaviorApplication {

    public static void main(String[] args) {
        SpringApplication.run(BehaviorApplication.class, args);
    }
}
