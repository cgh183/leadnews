package com.heima.hehavior.service;

public interface UnlikesBehaviorService {

    public ResponseResult unLike(UnLikesBehaviorDto dto);
}
