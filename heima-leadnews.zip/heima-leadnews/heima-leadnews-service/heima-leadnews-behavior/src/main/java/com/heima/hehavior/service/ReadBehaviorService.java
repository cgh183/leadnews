package com.heima.hehavior.service;

public interface ReadBehaviorService {

    /**
     * 阅读行为统计
     * @param dto
     * @return
     */
    public ResponseResult readBehavior(ReadBehaviorDto dto);
}
