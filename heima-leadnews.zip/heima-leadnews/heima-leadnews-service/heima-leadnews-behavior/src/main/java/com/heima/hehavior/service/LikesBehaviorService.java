package com.heima.hehavior.service;

public interface LikesBehaviorService {
    /**
     * 用户点赞与取消
     * @param dto
     * @return
     */
    public ResponseResult like(LikesBehaviorDto dto);

}
