package com.heima.article.service;

public class ApCollectionService {

    public ResponseResult collection(CollectionBehaviorDto dto);
}
